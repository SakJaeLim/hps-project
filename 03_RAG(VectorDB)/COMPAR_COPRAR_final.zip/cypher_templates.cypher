// ============ PortAgent GraphRAG — COPRAR 근거 검색 Cypher 템플릿 ============

// [Q1] 특정 제약의 규정 근거 세그먼트(EvidenceChunk) 조회 → GraphRAG 설명 그라운딩
MATCH (con:Constraint {type:$constraint_type})-[:SUPPORTED_BY]->(seg:Segment)-[:DESCRIBED_IN]->(d:Document)
RETURN con.rule_text, seg.title, seg.vector_ref AS chunk_id, seg.page, d.standard;

// [Q2] 특정 세그먼트가 쓰는 코드값과 의미 (코드 해석 설명)
MATCH (seg:Segment {segment_id:$segment_id})-[:USES_CODE]->(code:CodeValue)
RETURN seg.title, collect({code:code.code, meaning:code.meaning}) AS codes;

// [Q3] 위험물(DG) 제약 → 근거 문서 경로 (xAI 설명용)
MATCH path = (con:Constraint {type:'DG_segregation'})-[:SUPPORTED_BY]->(seg:Segment)
RETURN con.severity, seg.title, seg.vector_ref, [n IN nodes(path) | labels(n)[0]] AS path_labels;

// [Q4] 특정 요소코드(element)가 등장하는 모든 세그먼트 (스키마 탐색)
MATCH (e:Element {element_code:$element_code})<-[:HAS_ELEMENT]-(seg:Segment)
RETURN e.element_code, collect(seg.segment_id) AS segments;

// [Q5] 세그먼트 그룹 계층 구조 (메시지 구조 설명)
MATCH (seg:Segment)-[:PART_OF]->(sg:SegmentGroup)
RETURN sg.sg_id, sg.name, collect({segment:seg.segment_id, level:seg.level, usage:seg.usage}) AS members
ORDER BY sg.sg_id;

// ============ 운영 KG 연동 (COPRAR 인스턴스 → 적재 검증) ============

// [Q6] 양하 순서 위반(오버스토우) 탐지: 위 컨테이너가 더 가까운 POD인데 아래를 막는 경우
MATCH (upper:Container)-[:STACKED_ON]->(lower:Container)
WHERE upper.pod_order < lower.pod_order
MATCH (con:Constraint {type:'discharge_order'})-[:SUPPORTED_BY]->(seg:Segment)
RETURN lower.container_id AS blocked, upper.container_id AS blocker,
       lower.pod, upper.pod, seg.vector_ref AS evidence_chunk;

// [Q7] DG 격리 위반 후보: 인접 슬롯에 상호반응 IMDG class
MATCH (c1:Container {dg:true})-[:ASSIGNED_TO]->(s1:Slot)-[:ADJACENT_TO]->(s2:Slot)<-[:ASSIGNED_TO]-(c2:Container {dg:true})
WHERE c1.imdg_class <> c2.imdg_class
RETURN c1.container_id, c1.imdg_class, c2.container_id, c2.imdg_class, s1.bay, s2.bay;
