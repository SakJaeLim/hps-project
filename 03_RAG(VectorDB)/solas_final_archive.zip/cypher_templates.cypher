// ========= PortAgent GraphRAG — SOLAS 근거 검색 Cypher 템플릿 =========

// [Q1] 특정 제약의 SOLAS 근거 章 + 근거 청크 → 설명 그라운딩
MATCH (chap:Chapter)-[:SUPPORTS]->(con:Constraint {type:$constraint_type})
MATCH (con)-[:EVIDENCED_BY]->(ch:EvidenceChunk)
RETURN con.rule_text, chap.chapter_id, chap.title, ch.vector_ref AS chunk_id;

// [Q2] 사고/계기 사건이 촉발한 개정과 그 개정이 바꾼 章
MATCH (e:Event)<-[:TRIGGERED_BY]-(a:Amendment)-[:AMENDS]->(c:Chapter)
RETURN e.event_name AS event, a.year, a.eif_date, collect(c.chapter_id) AS chapters
ORDER BY a.year;

// [Q3] 특정 章의 개정 이력(연표)
MATCH (a:Amendment)-[:AMENDS]->(c:Chapter {chapter_id:$chapter_id})
RETURN c.title, a.year, a.eif_date, a.title ORDER BY a.year;

// [Q4] 특정 코드(IMDG/ISM/LSA...)를 참조하는 章/개정 청크
MATCH (ch:EvidenceChunk)-[:REFERENCES_CODE]->(code:Code {code:$code})
RETURN code.meaning, collect(ch.title) AS chunks;

// [Q5] 항만 적재 고관련(high) 규정만 — 적재 설명용 근거 후보
MATCH (ch:EvidenceChunk {port_relevance:'high'})-[:DESCRIBES]->(c:Chapter)
RETURN c.chapter_id, c.title, ch.title, ch.vector_ref;

// ========= 운영 KG 연동 (SOLAS 근거 → 적재 검증 설명) =========

// [Q6] 복원성 제약 위반 후보의 SOLAS 근거 동시 제시 (xAI)
MATCH (con:Constraint {type:'stability'})-[:EVIDENCED_BY]->(ch:EvidenceChunk)
OPTIONAL MATCH (con)-[:APPLIES_TO]->(c:Container)-[:ASSIGNED_TO]->(s:Slot)
RETURN con.rule_text, ch.vector_ref AS evidence, c.container_id, s.bay, s.tier;
